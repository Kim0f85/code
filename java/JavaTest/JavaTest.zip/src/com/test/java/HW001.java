package com.test.java;

public class HW001 {
	
	public static void main(String[] args) {
		//-------- float ---------
		float myWeight;
		myWeight = 75.2F;
		System.out.println("제 몸무게는 " + myWeight + "kg입니다");
		
		float mySpeed; 
		mySpeed = 99.2F; 
		System.out.println("자동차의 속도는 "+mySpeed+"KM 입니다");
		
		float myHeight; 
		myHeight = 18.2F; 
		System.out.println("제 키는 "+myHeight+"cm 입니다");
		
		float myPower; 
		myPower = 19.2F; 
		System.out.println("제 힘은 "+myPower+"입니다");
		
		float myJump;
		myJump = 1.89F; 
		System.out.println("방금 "+myJump+"미터를 뛰었습니다");
		
		float mySlide = 0.89F;
		System.out.println("방금 "+mySlide+"미터를 미끄러졌습니다");
		
		float myProfit = 12.29F; 
		System.out.println("이번연도 수익률은 "+myProfit+"% 입니다");
		
		float myAge = 25.2F; 
		System.out.println("제 나이는 "+myAge+"살 입니다");
		
		float myWinrate = 66.23F; 
		System.out.println("제 승률은 "+myWinrate+"% 입니다");
		
		float myShare = 32.2F; 
		System.out.println("제 지분률은 "+myShare+"% 입니다");
		
		//--------- byte -----------
		
		byte myKill = 12;
		System.out.println(myKill+"마리를 사냥했습니다");
		
		byte myPunch = 56; 
		System.out.println(myPunch+"번의 주먹질을 했습니다.");
		
		byte myFriend= 12; 
		System.out.println("친구의 나이는 "+myFriend+"살 입니다");
		
		byte myWin = 99;
		System.out.println("저는 "+myWin+"번 승리했습니다.");
		
		byte myLose = 12; 
		System.out.println("저는 "+myLose+"번 패배했습니다");
		
		byte myNumber = 66;
		System.out.println("제 등번호는 "+myNumber+"입니다");
		
		byte myComNum = 2;
		System.out.println("저는 "+myComNum+"대의 컴퓨터가 있습니다.");
		
		byte myClothNum = 15;
		System.out.println("저는 "+myClothNum+"벌의 옷을 가지고있습니다.");
		
		byte myDream = 88; 
		System.out.println("저는 "+myDream+"개의 꿈이 있습니다. ");
		
		byte myBook = 3;
		System.out.println("저는 "+myBook+"권의 책을 가지고 있습니다. ");
		
		//--------- short ---------
		
		short myDistHome = 12332;
		System.out.println("집가지의 거리가 "+myDistHome+"m 입니다");
		
		short myDistAway = 12345; 
		System.out.println("앞으로 "+myDistAway+"km나 더 가야합니다");
		
		short mySalary = 12345; 
		System.out.println("제 연봉은 "+mySalary+"입니다.");
		
		short mySpend = 12345; 
		System.out.println("일년동안 "+mySpend+"만원을 사용합니다. ");
		
		short myMonthly = 12345; 
		System.out.println("일년 이자비용이 "+myMonthly+"만원 입니다.");
		
		short myHobby = 12345;
		System.out.println("취미에 "+myHobby+"만원을 사용합니다 ");
		
		short mySaving =12345 ;
		System.out.println("월 "+mySaving+"만원을 저축합니다.");
		
		short myYearlySav= 12345;
		System.out.println("메년"+myYearlySav+"만원을 저축합니다");
		
		short myHosFee= 12345;
		System.out.println("제 병원비는 "+myHosFee+"입니다");
		
		short myCarCost= 12345;
		System.out.println("제 자동차는 "+myCarCost+"만원 입니다 ");
		
		//-------- int -----------
		
		int myEarning =123456789 ;
		System.out.println("이번년도에 "+myEarning+"원을 벌었습니다");
		
		int myExit= 123456789;
		System.out.println("주식을 팔아 "+myExit+"달러를 벌었습니다.");
		
		int myPurchase= 123456789;
		System.out.println("저는 저택을 "+myPurchase+"달러에 구매했습니다");
		
		int myWill= 123456789;
		System.out.println("저는 유산으로 "+myWill+"남겼습니다" );
		
		int myHouse=1234789 ;
		System.out.println("제 집의 시세는"+myHouse+"입니다");
		
		int myComp= 12345689;
		System.out.println("제 회사는 "+myComp+"의 가치를 가지고 있습니다");
		
		int mybuilding= 123456789;
		System.out.println("제빌딩은 "+mybuilding+"달러입니다");
		
		int myAsset= 455676789;
		System.out.println("제 자산은"+myAsset+"달러 입니다");
		
		int myWifeMon= 1267123189;
		System.out.println("제 아내의 재산은 "+myWifeMon+"입니다");
		
		int myHusMon = 123456789;
		System.out.println("제 남편의 재산은 "+myHusMon+"입니다");
		
		
		//-------- long --------
		
		long DistSun= 123423123123456789L;
		System.out.println("태양과의 거리는 "+DistSun+"km입니다");
		
		long VolSea= 3456789123456789L;
		System.out.println("바다의 부피는 "+VolSea+"^2입니다");
		
		long SizeSun= 126789123456789L;
		System.out.println("태양의 크기는 "+SizeSun+"입니다");
		
		long SizeJup= 123456756789L;
		System.out.println("목성의 크기는 "+SizeJup+"입니다");
		
		long SizeSat= 126789123456789L;
		System.out.println("토성의 크기는 "+SizeSat+"입니다");
		
		long SizeVen= 1234569123456789L;
		System.out.println("금성의 크기는 "+SizeVen+"입니다");
		
		long SizeMar= 1456789123456789L;
		System.out.println("화성의 크기는 "+SizeMar+"입니다");
		
		long SizePlu= 1236789123456789L;
		System.out.println("해왕성의 크기는 "+SizePlu+"입니다");
		
		long SizeTanker= 1234589123456789L;
		System.out.println("유선의 크기는 "+SizeTanker+"mm입니다");
		
		long SizeAirCar= 1234569123456789L;
		System.out.println("항공모함의 크기는 "+SizeAirCar+"입니다");
		

		//---------- double -------- 
		double DiffWin= 2.345D;
		System.out.println(DiffWin+"cm의 차이로 승리 했습니다");
		
		double DiffGrowth= 1.92345D ;
		System.out.println("작년보다 "+DiffGrowth+"cm 컷습니다");
		
		double EcoGrowth= 2.3455667D;
		System.out.println("작년보다 "+EcoGrowth+"%만큼 경제가 상승했습니다");
		
		double StocGrowth= 5.23487D;
		System.out.println(StocGrowth+"%만큼 주식이 상승 했습니다");
		
		double FxRise= 45.456788D;
		System.out.println("환률이 "+FxRise+"만큼 상승했습니다");
		
		double HeightGrow= 2.34567D;
		System.out.println(HeightGrow+"cm만큼 키가 컸습니다");
		
		double PortGrow= 4.456567D;
		System.out.println("주식 포트 포리오가 "+PortGrow+"%만큼 성장했습니다");
		
		double TaxRate= 12.345567D;
		System.out.println("이번년도 세금은 "+TaxRate+"%입니다 ");
		
		double VoteCount= 56.1342346D;
		System.out.println(VoteCount+" 득표율로 승리했습니다");
		
		double PetGrow= 2.345678D;
		System.out.println("줄루가 "+PetGrow+"cm만큼 성장했습니다");
		
		double LandLost= 0.235679D;
		System.out.println("메년 "+LandLost+"%의 땅이 바다로 사라지고 있습니다");
		
		
		//------- string --------
		String Suspect= "용두길";
		System.out.println("이번사건의 용의자는 " +Suspect+" 입니다");
		
		String AirCarri= "이순신함";
		System.out.println("대한민국의 항공모함의 이름은 "+AirCarri+" 입니다");
		
		String NicName= "과철용";
		System.out.println("어떤 영화배우는 이름보다 별명인 "+NicName+"으로 더잘 알려져있습니다");
		
		String Victum = "추필후";
		System.out.println("이번사건의 피해자는 "+Victum+" 입니다");
		
		String President= "김두광";
		System.out.println("우리나라 대통령의 이름은 "+President+" 입니다");
		
		String FriName= "김필식" ;
		System.out.println("친구의 이름은 "+FriName+" 입니다");
		
		String PlayName= "캣츠" ;
		System.out.println("연극의 이름은 "+PlayName+" 입니다");
		
		String DogName= "동팔이" ;
		System.out.println("강아지의 이름은 "+DogName+" 입니다");
		
		String CatName= "고냥이";
		System.out.println("고양이의 이름은 "+CatName+" 입니다");
		
		String CarName= "붕붕이";
		System.out.println("자동차의 이름은 "+CarName+" 입니다");
		
		
		//----------Char---------
		char MatGrade = 'A';
		System.out.println("이번학기 수학 점수는 "+MatGrade+"입니다");
		
		char BehGrade = 'D';
		System.out.println("이번학기 태도 점수는 "+BehGrade+"입니다");
		
		char KorGrade = 'B';
		System.out.println("저번학기 국어 점수는 "+KorGrade+"입니다");
		
		char EngGrade = 'A';
		System.out.println("이번학기 영어 점수는 "+EngGrade+"입니다");
		
		char SocGrade = 'D';
		System.out.println("이번학기 사회 점수를 "+SocGrade+"받고싶습니다");
		
		char PEGrade = 'B';
		System.out.println("저저번학기 채육 점수는 "+PEGrade+"입니다");
		
		char SciGrade = 'D';
		System.out.println("전번학기 과학 점수는 "+SciGrade+"입니다");
		
		char FreGrade = 'A';
		System.out.println("이번학기 프랑스 점수는 "+FreGrade+"입니다");
		
		char PhyGrade = 'B';
		System.out.println("이번학기 물리 점수는 "+PhyGrade+"입니다");
		
		char MagGrade = 'A';
		System.out.println("마법 점수는 "+MagGrade+"드리겠습니다");
		
		
		//-----------boolean----------
		boolean flag = true; 
		System.out.println("진실을 말하고 있나요 ? "+flag);
		
		boolean flag1 = false; 
		System.out.println("지금 그사람이 거짓말을 하고 있나요 ? " +flag1);
		
		boolean flag2 = true; 
		System.out.println("지금 이렇게 하면 살려주시나요? "+flag2);
		
		boolean flag3 = false; 
		System.out.println("여기서 도망치게 해주실 건가요? "+flag3);
		
		boolean flag4 = true; 
		System.out.println("돈을 갚을 건가요? "+flag4);
		
		boolean flag5 = false; 
		System.out.println("돈은 가져 오셨나요? "+flag5);
		
		boolean flag6 = true; 
		System.out.println("돈이 남아있으신가요 ? "+flag6);
		
		boolean flag7 = false; 
		System.out.println("돈좀 빌려주실수 있나요? "+flag7);
		
		boolean flag8 = true; 
		System.out.println("진실만을 말하시나요? "+flag8);
		
		boolean flag9 = false; 
		System.out.println("당신은 인간입니까? "+flag9);
		
		
	
		
		

	}
}
